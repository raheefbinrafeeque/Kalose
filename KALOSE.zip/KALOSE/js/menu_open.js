$(document).ready(function() {

	const menu = document.querySelector("svg");
	menu.addEventListener("click", morph);

	function morph() {
	  menu.classList.toggle("open");
	};


	if ($(window).width() < 1120) {

	$(".ctr_btn").click(function() {
		$(".ctr_btn").toggleClass("open");
	});
	
	$(".mega_link").click(function() {
		$(".mega_link").toggleClass('open');
	});
	
	$(".sub_link").click(function() {
		$(".sub_link").toggleClass('open');
	});

	$(".sub_link_2").click(function() {
		$(".sub_link_2").toggleClass('open');
	});

	}
	else {

	$(".ctr_btn").hover(function() {
		$(".ctr_btn").toggleClass("open");
	});
	
	$(".mega_link").hover(function() {
		$(".mega_link").toggleClass('open');
	});
	
	$(".sub_link").hover(function() {
		$(".sub_link").toggleClass('open');
	});

	$(".sub_link_2").hover(function() {
		$(".sub_link_2").toggleClass('open');
	});
	}

    // $('.social_chat_block > a').on('click', function(event) {
    //   	$('.social_chat_block').toggleClass("chat_on");
    //   	$(".social_chat_area").toggleClass("is-visible");
    //   });


    // $('.close_chat').on('click', function(event) {
    //   	$('.social_chat_block').removeClass("chat_on");
    //   	$(".social_chat_area").removeClass("is-visible");
    //   });


});